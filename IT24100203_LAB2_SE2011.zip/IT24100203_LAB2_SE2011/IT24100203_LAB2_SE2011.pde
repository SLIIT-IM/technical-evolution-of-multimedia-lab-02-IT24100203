void setup() {
  size(800, 600);
  noStroke();
}

void draw() {
  background(230, 240, 255);  

  for (int x = 0; x < width; x += 40) {

    if ((x / 40) % 2 == 0) {
      fill(173, 216, 230);      
    } else {
      fill(255);   
    }

    rect(x, 0, 40, height);
  }
}
